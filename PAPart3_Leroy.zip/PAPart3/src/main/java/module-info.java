module com.example.papart3 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.papart3 to javafx.fxml;
    exports com.example.papart3.Controller;
    opens com.example.papart3.Controller to javafx.fxml;
    exports com.example.papart3.Model;
    opens com.example.papart3.Model to javafx.fxml;
    exports com.example.papart3;
}