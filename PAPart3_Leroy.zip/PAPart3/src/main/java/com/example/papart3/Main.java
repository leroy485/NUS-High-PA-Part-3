package com.example.papart3;

import javafx.application.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.stage.*;
import java.io.*;

public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("View/main.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 918, 600);
        stage.setTitle("Hip Living! Cozy Living At Your Doorstep");
        stage.setScene(scene);
        stage.show();
    }
    public static void main(String[] args) {
        launch();
    }
}