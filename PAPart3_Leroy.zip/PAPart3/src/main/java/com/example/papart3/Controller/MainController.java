package com.example.papart3.Controller;

// Import Statements

import com.example.papart3.Model.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.shape.*;
import javafx.stage.*;
import java.io.*;
import java.text.*;
import java.util.*;
import com.example.papart3.Main;

public class MainController {
    // FXML Objects
    @FXML
    public TextField usernameTF;
    @FXML
    public PasswordField passwordTF;
    @FXML
    public Button loginBtn;
    @FXML
    public Label welcomeLabel;
    @FXML
    public Label pickCatLabel;
    @FXML
    public TextArea catTA;
    @FXML
    public Label catLabel;
    @FXML
    public TextField catOptTF;
    @FXML
    public Button catBtn;
    @FXML
    public Label pointsLabel;
    @FXML
    public Button aboutBtn;
    @FXML
    public Button redeemMainBtn;
    @FXML
    public Label numItemsLabel;
    @FXML
    public Button removeMainBtn;
    @FXML
    public Button checkoutBtn;
    @FXML
    public TextArea cartTA;
    @FXML
    public Label optLabel;
    @FXML
    public TextField optTF;
    @FXML
    public Button removeBtn;
    @FXML
    public Label max100Label;
    @FXML
    public TextField redeemTF;
    @FXML
    public Button redeemBtn;
    @FXML
    public Label cartLabel;
    @FXML
    public Line line;
    @FXML
    public Button addToCartBtn;
    @FXML
    public Button warrantyBtn;

    // Global variables

    public Security security = new Security(System.getProperty("user.dir") + "/Secure.csv");
    public Database database = new Database(System.getProperty("user.dir") + "/Customer.csv", System.getProperty("user.dir") + "/Furniture.csv",System.getProperty("user.dir") + "/Courier.csv");
    public Alert alert = new Alert(Alert.AlertType.NONE);
    public boolean login = false;
    public ArrayList<Furniture> furnitureDB = new ArrayList<>();
    public ArrayList<Account> accountDB = new ArrayList<>();
    public Account currAccount;
    public Customer currCustomer;
    public ArrayList<String> categories = new ArrayList<>();
    public ArrayList<Furniture> shoppingCart = new ArrayList<>();
    public ArrayList<Furniture> furnitureOfCat = new ArrayList<>();
    public double originalPoints = 0;
    public double totalCost = getTotalCost(shoppingCart);
    public String shoppingCartStr;
    public String categoriesStr;
    public double currPoints = originalPoints;
    public boolean hasFreeDelivery;
    public boolean hasPaidDelivery;
    public boolean choseFreeDelivery;
    public boolean chosePaidDelivery;
    public int warrantyOption;
    public int numOptions = 0;
    public int currIndex = 0;
    public Furniture f;
    public boolean proceed;
    public String warrantyStr;
    public String transaction;
    public boolean hasPointsDiscount;
    public double pointsRedeemed;
    public boolean redeemIsValid = true;
    public boolean isPointsRedeemed = false;

    public void initialize() throws IOException, ParseException { // Initializes the GUI upon launch.
        hideEverything();
        BufferedReader inputStream = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/Furniture.csv")); // Reads the furniture file and adds all furniture to allFurniture
        String line = "";
        String[] tokens;
        while (line != null) {
            line = inputStream.readLine();
            if (line != null) {
                tokens = line.split("[,]+");
                if (tokens.length == 4) { // The respective furniture constructors are called accordingly depending on whether it is ordered or not
                    furnitureDB.add(new Furniture(tokens[0],tokens[1],tokens[2],Double.parseDouble(tokens[3])));
                } else {
                    furnitureDB.add(new Furniture(tokens[0],tokens[1],tokens[2],Double.parseDouble(tokens[3]),tokens[4],tokens[5],tokens[6].charAt(0)));
                }
            }
        }
        inputStream.close();
        BufferedReader inputStream2 = new BufferedReader(new FileReader(System.getProperty("user.dir") + "/Secure.csv")); // Reads the secure file and adds all accounts to allAccounts
        line = "";
        while (line != null) {
            line = inputStream2.readLine();
            if (line != null) {
                tokens = line.split("[,]+");
                accountDB.add(new Account(tokens[0],tokens[1],tokens[2],Double.parseDouble(tokens[3])));
            }
        }
        inputStream2.close();
        cartTA.setEditable(false);
        catTA.setEditable(false);
    }

    public void handleAbout(ActionEvent e) throws IOException { // Handles About Programmer Button
        FXMLLoader fxmlLoader = new FXMLLoader(Main.class.getResource("View/about.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("About Programmer");
        stage.setScene(scene);
        stage.show();
    }

    public void handleLogin(ActionEvent e) { // Handles Login (or Logout) button
        if (!login) {
            login(usernameTF.getText(),passwordTF.getText());
        } else {
            logout();
        }
    }

    public void login(String username, String password) { // Login case of handleLogin
        if (security.login(username, password)) {
            // Initializes everything.
            numItemsLabel.setText("You have 0 items in your shopping cart.");
            login = true;
            hasPaidDelivery = false;
            hasPointsDiscount = false;
            hasPaidDelivery = false;
            chosePaidDelivery = false;
            choseFreeDelivery = false;
            loginBtn.setText("Logout");
            usernameTF.setDisable(true);
            passwordTF.setDisable(true);
            security = new Security(System.getProperty("user.dir") + "/Secure.csv");
            database = new Database(System.getProperty("user.dir") + "/Customer.csv",System.getProperty("user.dir") + "/Furniture.csv",System.getProperty("user.dir") + "/Courier.csv");
            String currCustomerID = Security.getCurrCustomerLogin();
            currAccount = security.getAccount(currCustomerID);
            currCustomer = database.getCustomer(currCustomerID);
            originalPoints = currAccount.getPoints();
            System.out.println("Original points" + originalPoints);
            currPoints = originalPoints;
            pickCatLabel.setText("Pick a category.");
            catLabel.setText("Category option:");
            redeemTF.clear();
            catOptTF.clear();
            optTF.clear();
            cartTA.setDisable(false);
            removeMainBtn.setDisable(false);
            checkoutBtn.setDisable(false);
            optTF.setDisable(false);
            removeBtn.setDisable(false);
            loginProcedure();
        } else {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Login error!");
            alert.setContentText("Username or password invalid!");
            alert.show();
        }
    }

    public void logout() { // Logout case of handleLogin
        usernameTF.setDisable(false);
        passwordTF.setDisable(false);
        usernameTF.clear();
        passwordTF.clear();
        hideEverything();
        loginBtn.setText("Login");
        currAccount = null;
        currCustomer = null;
        shoppingCart.clear();
        shoppingCartStr = "";
        currPoints = 0;
        hasFreeDelivery = false;
        hasPaidDelivery = false;
        choseFreeDelivery = false;
        chosePaidDelivery = false;
        originalPoints = 0;
        totalCost = 0;
        cartTA.clear();
        catTA.clear();
        login = false;
        hasPointsDiscount = false;
        pointsRedeemed = 0;
    }

    public void loginProcedure() { // After successful login, to initialize everything to the current customer and account
        welcomeLabel.setText("Hi " + currCustomer.getName() + ", welcome to Hip Living!");
        pointsLabel.setText("You have " + String.format("%.2f",currAccount.getPoints()) + " points.");
        categories = database.getFurnitureCategories();
        categoriesStr = "";
        for (int i = 0; i < categories.size(); i++) {
            categoriesStr += (i+1) + ") " + categories.get(i) + "\n";
        }
        catTA.setText(categoriesStr);
        shoppingCartStr = "";
        showEverything();
    }

    public void handleRedeemMain(ActionEvent e) { // Handle Redeem points for discount button
        redeemTF.setVisible(true);
        redeemBtn.setVisible(true);
        max100Label.setVisible(true);
    }

    public void handleCatBtn(ActionEvent e) { // Handle select category button
        try {
            int option = Integer.parseInt(catOptTF.getText());
            if (option >= 1 && option <= categories.size()) { // Check if option entered is valid.
                String category = categories.get(option-1);
                furnitureOfCat = database.getUnorderedFurnitureList(category,shoppingCart);
                catBtn.setVisible(false);
                addToCartBtn.setVisible(true);
                catLabel.setText("Select your furniture option:");
                pickCatLabel.setText("Pick a " + category + " furniture:");
                catOptTF.clear();
                String furnitureStr = "";
                int i = 0;
                for (i = 0; i < furnitureOfCat.size(); i++) {
                    furnitureStr += (i+1) + ") " + furnitureOfCat.get(i).toString() + "\n";
                }
                furnitureStr += (i+1) + ") Back to main menu";
                catTA.setText(furnitureStr); // Display the furniture of the category.
            } else {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid category");
                alert.setContentText("Enter a number from 1 to " + categories.size());
                alert.show();
            }
        } catch (Exception ex) {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Invalid category");
            alert.setContentText("Enter a number from 1 to " + categories.size());
            alert.show();
        }
    }

    public void handleAddToCartBtn(ActionEvent e) { // Handle add to cart button
        try {
            int option = Integer.parseInt(catOptTF.getText());
            if (option >= 1 && option <= furnitureOfCat.size()+1) { // Check if furniture option is valid.
                if (option != furnitureOfCat.size()+1) {
                    Furniture furnitureSelected = furnitureOfCat.get(option - 1);
                    shoppingCart.add(furnitureSelected);
                    totalCost = getTotalCost(shoppingCart);
                    updateShoppingCartStr();
                    cartTA.setText(shoppingCartStr);
                    catTA.setText(categoriesStr);
                    pickCatLabel.setText("Pick a category.");
                    catLabel.setText("Category option:");
                    addToCartBtn.setVisible(false);
                    catBtn.setVisible(true);
                    catOptTF.clear();
                    numItemsLabel.setText("You have " + shoppingCart.size() + " items in your shopping cart.");
                } else {
                    catTA.setText(categoriesStr);
                    catOptTF.clear();
                    pickCatLabel.setText("Pick a category.");
                    catLabel.setText("Category option:");
                    addToCartBtn.setVisible(false);
                    catBtn.setVisible(true);
                }
            } else {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid furniture");
                alert.setContentText("Enter a number from 1 to " + (furnitureOfCat.size()+1));
                alert.show();
            }
        } catch (Exception ex) {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Invalid furniture");
            alert.setContentText("Enter a number from 1 to " + (furnitureOfCat.size()+1));
            alert.show();
        }
    }

    public void updateShoppingCartStr() { // Updates the shopping cart string which is then later updated to the shopping cart textarea, whenever needed
        shoppingCartStr = "Your order:";
        shoppingCartStr += "\n";
        for (int i = 0; i < shoppingCart.size(); i++) {
            shoppingCartStr += (i + 1) + ") " + shoppingCart.get(i).toString() + "\n";
        }
        System.out.println(hasPointsDiscount);
        if (!chosePaidDelivery) {
            shoppingCartStr += "------------------------------\nTotal cost: $" + String.format("%.2f", getTotalCost(shoppingCart)) + "\n------------------------------";
            if (hasPointsDiscount) {
                totalCost = (((100 - Account.calcPercentDiscount(pointsRedeemed)) / 100) * getTotalCost(shoppingCart));
                shoppingCartStr += "\nTotal cost after discount: $" + String.format("%.2f", totalCost) + "\n------------------------------";
            }
            System.out.println(shoppingCartStr);
        } else {
            totalCost += 30;
            shoppingCartStr += "------------------------------\nTotal cost: $" + String.format("%.2f",getTotalCost(shoppingCart)+30) + "\n------------------------------";
            if (hasPointsDiscount) {
                totalCost = (((100 - Account.calcPercentDiscount(pointsRedeemed)) / 100) * getTotalCost(shoppingCart));
                totalCost += 30;
                shoppingCartStr += "\nTotal cost after discount: $" + String.format("%.2f", totalCost) + "\n------------------------------";
            }
        }
    }

    public void handleRemoveMainBtn(ActionEvent e) { // Handles Remove Item button
        if (shoppingCart.size() > 0) {
            optLabel.setVisible(true);
            optTF.setVisible(true);
            removeBtn.setVisible(true);
        } else {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Shopping cart is empty!");
            alert.setContentText("Please add items to the shopping cart!");
            alert.show();
        }
    }

    public void handleRemoveBtn(ActionEvent e) { // Handles Remove button
        try {
            int option = Integer.parseInt(optTF.getText());
            if (option >= 1 && option <= shoppingCart.size()) { // Check if furniture to be removed is a valid option.
                totalCost -= shoppingCart.get(option-1).getCost();
                shoppingCart.remove(option-1);
                updateShoppingCartStr();
                cartTA.setText(shoppingCartStr);
                numItemsLabel.setText("You have " + shoppingCart.size() + " items in your shopping cart.");
            } else {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Invalid furniture selected");
                alert.setContentText("Enter a number from 1 to " + shoppingCart.size());
                alert.show();
            }
            optLabel.setVisible(false);
            optTF.setVisible(false);
            removeBtn.setVisible(false);
            optTF.clear();
        } catch (Exception ex) {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Invalid furniture selected");
            alert.setContentText("Enter a number from 1 to " + shoppingCart.size());
            alert.show();
            optLabel.setVisible(false);
            optTF.setVisible(false);
            removeBtn.setVisible(false);
            optTF.clear();
        }
    }

    public void handleRedeem(ActionEvent e) { // Handles Redeem button
        try {
            pointsRedeemed = Integer.parseInt(redeemTF.getText());
            System.out.println(currAccount);
            currPoints = originalPoints;
            currAccount = new Account(currAccount.getLoginID(),currAccount.getPassword(),currAccount.getCustomerID(),originalPoints);
            if (pointsRedeemed >= 0 && pointsRedeemed <= 100) {
                String str = currAccount.deductPoints(pointsRedeemed);
                if (str.startsWith("Insufficient")) {
                    hasPointsDiscount = false;
                    redeemIsValid = false;
                    pointsLabel.setText("You have " + String.format("%.2f", originalPoints) + " points.\nInsufficient points to deduct.");
                    currPoints += pointsRedeemed;
                } else {
                    hasPointsDiscount = true;
                    redeemIsValid = true;
                    currPoints = currAccount.getPoints();
                    if (choseFreeDelivery) {
                        currPoints -= 50;
                    }
                    updateShoppingCartStr();
                    cartTA.setText(shoppingCartStr);
                    pointsLabel.setText("You have " + String.format("%.2f", originalPoints) + " points.\nAfter redemption: " + String.format("%.2f", currPoints) + " points.");
                }
            } else {
                hasPointsDiscount = false;
                redeemIsValid = false;
                pointsLabel.setText("You have " + String.format("%.2f",originalPoints) + " points.\nEnter a non-negative integer!");
            }
        } catch (Exception ex) {
            pointsLabel.setText("You have " + String.format("%.2f",originalPoints) + " points.\nEnter a non-negative integer!");
            hasPointsDiscount = false;
            redeemIsValid = false;
        }
    }

    public void handleCheckout(ActionEvent e) { // Handles Checkout button
        if (redeemIsValid) {
            try {
                hasFreeDelivery = false;
                hasPaidDelivery = false;
                proceed = false;
                cartTA.setDisable(true);
                removeMainBtn.setDisable(true);
                removeBtn.setDisable(false);
                checkoutBtn.setDisable(false);
                if (shoppingCart.size() != 0) {
                    alert = new Alert(Alert.AlertType.CONFIRMATION);
                    ButtonType yesBtn = new ButtonType("Yes", ButtonBar.ButtonData.CANCEL_CLOSE);
                    ButtonType noBtn = new ButtonType("No", ButtonBar.ButtonData.CANCEL_CLOSE);
                    if (currPoints >= 50) {
                        alert.setHeaderText("Would you like free delivery service?");
                        alert.setContentText("50 points will be redeemed.");
                        hasFreeDelivery = true;
                    } else {
                        alert.setHeaderText("Would you like paid delivery service?");
                        alert.setContentText("$30 will be added to your final bill.");
                        hasPaidDelivery = true;
                    }
                    alert.getButtonTypes().setAll(yesBtn, noBtn);
                    Optional<ButtonType> confirm = alert.showAndWait();
                    if (hasFreeDelivery) {
                        if (confirm.get() == yesBtn) { // User chose the yes button.
                            currPoints -= 50;
                            pointsLabel.setText("You have " + String.format("%.2f", originalPoints) + " points.\nAfter redemption: " + String.format("%.2f", currPoints) + " points.");
                            choseFreeDelivery = true;
                        } else {
                            choseFreeDelivery = false;
                        }
                    } else if (hasPaidDelivery) {
                        if (confirm.get() == yesBtn) { // User chose the yes button.
                            chosePaidDelivery = true;
                            updateShoppingCartStr();
                            cartTA.setText(shoppingCartStr);
                        } else {
                            chosePaidDelivery = false;
                        }
                    }
                    alert.setTitle("Confirm Order?");
                    alert.setHeaderText("Confirm Order?");
                    alert.setContentText("");
                    Optional<ButtonType> confirm2 = alert.showAndWait();
                    if (confirm2.get() == yesBtn) {
                        pickCatLabel.setText("Select warranty type");
                        catLabel.setText("Choose warranty option:");
                        warrantyBtn.setVisible(true);
                        catBtn.setVisible(false);
                        addToCartBtn.setVisible(false);
                        currIndex = 0;
                        nextFurniture();
                    } else {
                        alert.hide();
                        cartTA.setDisable(false);
                        removeMainBtn.setDisable(false);
                        removeBtn.setDisable(false);
                        checkoutBtn.setDisable(false);
                        if (choseFreeDelivery) {
                            System.out.println("abc");
                            currPoints += 50;
                            pointsRedeemed = 0;
                            updateShoppingCartStr();
                            pointsLabel.setText("You have " + String.format("%.2f",originalPoints) + " points.\nAfter redemption: " + String.format("%.2f",currPoints) + " points.");
                            choseFreeDelivery = false;
                        }
                        if (chosePaidDelivery) {
                            System.out.println("def");
                            totalCost -= 30;
                            chosePaidDelivery = false;
                            updateShoppingCartStr();
                            cartTA.setText(shoppingCartStr);
                        }
                    }
                } else {
                    cartTA.setDisable(false);
                    removeMainBtn.setDisable(false);
                    checkoutBtn.setDisable(false);
                    optTF.setDisable(false);
                    removeBtn.setDisable(false);
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Shopping cart is empty!");
                    alert.setContentText("Please select at least 1 furniture.");
                    alert.show();
                }
            } catch (Exception ex) {
            }
        } else {
            alert = new Alert(Alert.AlertType.ERROR);
            alert.setHeaderText("Invalid points redeemed!");
            alert.setContentText("Please change to a valid number of points before checkout");
            alert.show();
        }
    }

    public void nextFurniture() { // Goes to the next furniture when selecting warranty.
        checkoutBtn.setDisable(true);
        Furniture currFurniture = shoppingCart.get(currIndex);
        warrantyStr = currFurniture.toString() + "\n";
        numOptions = warrantyMenu(currFurniture.getCost());
        if (numOptions >= 1) {
            warrantyStr += "1) No warranty\n";
        }
        if (numOptions >= 2) {
            warrantyStr += "2) Low warranty\n";
        }
        if (numOptions >= 3) {
            warrantyStr += "3) Medium warranty\n";
        }
        if (numOptions >= 4) {
            warrantyStr += "4) High warranty\n";
        }
        catTA.setText(warrantyStr);
    }

    public void handleWarrantyBtn(ActionEvent e) throws IOException, ParseException { // Handles select warranty button
        try {
            warrantyOption = Integer.parseInt(catOptTF.getText());
            Furniture currFurniture = shoppingCart.get(currIndex);
            if (warrantyOption >= 1 && warrantyOption <= warrantyMenu(currFurniture.getCost())) { // Check if warranty option is valid.
                handleRedeem(e);
                if (redeemIsValid) {
                    currFurniture.setWarrantyLevel(getWarranty(warrantyOption));
                    currFurniture.setOrderDate(new Date());
                    currFurniture.setCustomerID(currCustomer.getCustomerID());
                    currFurniture.setOrdered(true);
                    if (currIndex < shoppingCart.size() - 1) {
                        currIndex++;
                        nextFurniture();
                    } else {
                        proceed = true;
                    }
                    catOptTF.clear();
                    System.out.println(currFurniture);
                    if (proceed) {
                        checkoutPart2();
                    }
                } else {
                    alert = new Alert(Alert.AlertType.ERROR);
                    alert.setHeaderText("Invalid points redeemed!");
                    alert.setContentText("Please change to a valid points before proceeding.");
                    alert.show();
                }
            } else {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Warranty option is invalid!");
                alert.setContentText("Enter a number from 1 to " + numOptions);
                alert.show();
            }
        } catch (NumberFormatException ex) {
            if (!proceed) {
                alert = new Alert(Alert.AlertType.ERROR);
                alert.setHeaderText("Warranty option is invalid!");
                alert.setContentText("Enter a number from 1 to " + numOptions);
                alert.show();
            }
        }
    }

    public void checkoutPart2() throws IOException, ParseException { // Continuation of checkout
        alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Transaction completed");
        alert.setHeaderText("Please view your order");
        alert.setContentText("Click on the arrow (Show details) to see details");
        if (chosePaidDelivery || choseFreeDelivery) {
            useDelivery();
        } else {
            useNoDelivery();
        }
        TextArea transactionTA = new TextArea(transaction);
        transactionTA.setEditable(false);
        transactionTA.setWrapText(true);
        GridPane expContent = new GridPane();
        expContent.add(transactionTA,0,0);
        alert.getDialogPane().setExpandableContent(expContent);
        ButtonType okBtn = new ButtonType("OK", ButtonBar.ButtonData.CANCEL_CLOSE);
        alert.getButtonTypes().setAll(okBtn);
        alert.show();
        if (currPoints + 0.1*totalCost > 999) {
            currPoints = 999;
        } else {
            currPoints += 0.1*totalCost;
        }
        pointsLabel.setText("You have " + String.format("%.2f",currPoints) + " points.");
        writeTransaction(transaction);
        pickCatLabel.setText("Pick a category.");
        catTA.setText(categoriesStr);
        catLabel.setText("Category option:");
        catBtn.setVisible(true);
        addToCartBtn.setVisible(false);
        warrantyBtn.setVisible(false);
        cartTA.setDisable(false);
        removeMainBtn.setDisable(false);
        checkoutBtn.setDisable(false);
        removeBtn.setDisable(false);
        cartTA.clear();
        numItemsLabel.setText("You have 0 items in your shopping cart.");
        currAccount = new Account(currAccount.getLoginID(),currAccount.getPassword(),currAccount.getCustomerID(),currPoints);
        pointsLabel.setText("You have " + String.format("%.2f",currPoints) + " points.");
        updateCsvFiles();
        database.writeFurniture("Furniture.csv");
        originalPoints = currPoints;
        shoppingCartStr = "";
        hasFreeDelivery = false;
        hasPaidDelivery = false;
        choseFreeDelivery = false;
        chosePaidDelivery = false;
        totalCost = 0;
        cartTA.clear();
        login = false;
        hasPointsDiscount = false;
        pointsRedeemed = Integer.parseInt(redeemTF.getText());
        currIndex = 0;
        transaction = "";
        redeemTF.clear();
    }

    public void useDelivery() throws IOException, ParseException {
        int noOfMovers;
        if (shoppingCart.size() % 5 != 0) { // Find noOfMovers
            noOfMovers = shoppingCart.size() / 5 + 1;
        } else {
            noOfMovers = shoppingCart.size() / 5;
        }
        ArrayList<Mover> moverArrayList = new ArrayList<>(noOfMovers);
        int index = 0;
        Mover currMover;
        for (int a = 0; a < noOfMovers - 1; a++) { // Accounts for all the couriers who have full 5 furniture
            currMover = new Mover(database.getNextCourier()[0],database.getNextCourier()[1],database.getNextCourier()[2]); // Get next available courier
            currMover.setCustomer(database.getCustomer(security.getCurrCustomerLogin())); // Set next available courier to current customer
            for (int b = 0; b < 5; b++) { // Each courier can only hold 5 items max
                currMover.addMoveItems(shoppingCart.get(index));
                index++;
            }
            moverArrayList.add(currMover);
        }
        currMover = new Mover(database.getNextCourier()[0],database.getNextCourier()[1],database.getNextCourier()[2]); // Accounts for the last courier (if applicable where shoppingCart.size() % 5 != 0) who has less than 5 items
        currMover.setCustomer(database.getCustomer(security.getCurrCustomerLogin()));
        for (int a = index; a < shoppingCart.size(); a++) {
            currMover.addMoveItems(shoppingCart.get(index));
            index++;
        }
        moverArrayList.add(currMover);
        transaction = "";
        for (Mover m: moverArrayList) { // Print transaction details
            transaction += m.toString();
            transaction += "\n";
        }
        shoppingCart.clear();
    }

    public void useNoDelivery() throws IOException, ParseException {
        Mover m = new Mover(shoppingCart.size());
        m.setCustomer(database.getCustomer(Security.getCurrCustomerLogin()));
        for (Furniture i: shoppingCart) {
            m.addMoveItems(i);
        }
        System.out.println(m);
        transaction = m.toString();
        System.out.println(transaction);
        shoppingCart.clear();
    }

    public void writeTransaction(String transaction) { // Writes into Transaction.txt
        try {
            FileWriter output = new FileWriter("Transaction.txt",true);
            output.write(transaction);
            output.write("");
            output.close();
        } catch (IOException e) {
        }
    }

    public void updateCsvFiles() throws IOException, ParseException {
        FileWriter output = new FileWriter(System.getProperty("user.dir") + "/Furniture.csv",false); // Updating Furniture.csv
        ArrayList<Integer> indicesOfOrderedFurniture = new ArrayList<>();
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        Date orderDate = new Date();
        Calendar c = Calendar.getInstance();
        c.setTime(orderDate);
        c.add(Calendar.DAY_OF_MONTH, 3);
        String orderDateStr = format.format(orderDate);
        for (Furniture f1: shoppingCart) {
            for (Furniture f2: furnitureDB) {
                if (f1.getFurnitureID().equals(f2.getFurnitureID())) {
                    indicesOfOrderedFurniture.add(furnitureDB.indexOf(f2));
                }
            }
        }
        for (Integer i: indicesOfOrderedFurniture) {
            furnitureDB.set(furnitureDB.indexOf(furnitureDB.get(i)),new Furniture(furnitureDB.get(i).getFurnitureID(),furnitureDB.get(i).getName(),furnitureDB.get(i).getCategory(),furnitureDB.get(i).getCost(),orderDateStr, Security.getCurrCustomerLogin(),furnitureDB.get(i).getWarrantyLevel())); // Replace the furniture with the updated furniture
        }
        for (Furniture f: furnitureDB) {
            if (f.isOrdered()) {
                output.write(f.getFurnitureID() + "," + f.getName() + "," + f.getCategory() + "," + f.getCost() + "," + f.getOrderDate() + "," + f.getCustomerID() + "," + f.getWarrantyLevel());
                output.write("\n");
            } else {
                output.write(f.getFurnitureID() + "," + f.getName() + "," + f.getCategory() + "," + f.getCost());
                output.write("\n");
            }
        }
        output.close();
        Account a = security.getAccount(Security.getCurrCustomerLogin());
        int aindex = 0; // Represents the index of the account (in Secure.csv) that is currently in use.
        FileWriter output2 = new FileWriter(System.getProperty("user.dir") + "/Secure.csv",false); // Updating Secure.csv
        for (Account acc: accountDB) {
            if (acc.getCustomerID().equals(Security.getCurrCustomerLogin())) {
                aindex = accountDB.indexOf(acc);
            }
        }
        accountDB.set(aindex,new Account(accountDB.get(aindex).getLoginID(),accountDB.get(aindex).getPassword(),accountDB.get(aindex).getCustomerID(),currPoints)); // Replace the account with the updated account.
        for (Account acc: accountDB) {
            output2.write(acc.getLoginID() + "," + acc.getPassword() + "," + acc.getCustomerID() + "," + acc.getPoints());
            output2.write("\n");
        }
        output2.close();
        shoppingCart.clear(); // Reset shoppingCart
    }

    public void hideEverything() {
        welcomeLabel.setVisible(false);
        pickCatLabel.setVisible(false);
        catTA.setVisible(false);
        catLabel.setVisible(false);
        catOptTF.setVisible(false);
        catBtn.setVisible(false);
        pointsLabel.setVisible(false);
        redeemBtn.setVisible(false);
        redeemMainBtn.setVisible(false);
        numItemsLabel.setVisible(false);
        removeBtn.setVisible(false);
        removeMainBtn.setVisible(false);
        checkoutBtn.setVisible(false);
        cartTA.setVisible(false);
        optLabel.setVisible(false);
        max100Label.setVisible(false);
        redeemTF.setVisible(false);
        cartLabel.setVisible(false);
        optTF.setVisible(false);
        line.setVisible(false);
        addToCartBtn.setVisible(false);
        warrantyBtn.setVisible(false);
    }

    public void showEverything() {
        welcomeLabel.setVisible(true);
        pickCatLabel.setVisible(true);
        catTA.setVisible(true);
        catLabel.setVisible(true);
        catOptTF.setVisible(true);
        catBtn.setVisible(true);
        pointsLabel.setVisible(true);
        redeemMainBtn.setVisible(true);
        numItemsLabel.setVisible(true);
        removeMainBtn.setVisible(true);
        checkoutBtn.setVisible(true);
        cartTA.setVisible(true);
        cartLabel.setVisible(true);
        line.setVisible(true);
    }

    public double getTotalCost(ArrayList<Furniture> shoppingCart) {
        double totalCost = 0;
        for (int i = 0; i < shoppingCart.size(); i++) {
            totalCost += shoppingCart.get(i).getCost();
        }
        return totalCost;
    }

    public int warrantyMenu(double cost){
        int options = 1;
        System.out.println("Select an option:");
        System.out.println("1) No warranty");
        if (cost >= 100){
            options++;
            System.out.println(options + ") Low Warranty");
        }
        if (cost >= 250){
            options++;
            System.out.println(options + ") Medium Warranty");
        }
        if (cost >= 500){
            options++;
            System.out.println(options + ") High Warranty");
        }
        return options;
    }

    public char getWarranty(int option){
        switch(option){
            case 1: return 'N';
            case 2: return 'L';
            case 3: return 'M';
            case 4: return 'H';
        }
        return 'N';
    }
}