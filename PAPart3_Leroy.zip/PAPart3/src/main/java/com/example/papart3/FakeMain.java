package com.example.papart3;

public class FakeMain {
    public static void main(String[] args) {
        Main.main(null);
    }
}
